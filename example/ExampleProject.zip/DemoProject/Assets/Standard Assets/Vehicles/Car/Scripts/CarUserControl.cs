using System;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

namespace UnityStandardAssets.Vehicles.Car
{
    [RequireComponent(typeof (CarController))]
    public class CarUserControl : MonoBehaviour
    {
        private CarController m_Car; // the car controller we want to use

        public bool _takeInput = false;

        private void Awake()
        {
            // get the car controller
            m_Car = GetComponent<CarController>();
        }


        private void FixedUpdate()
        {
            if( _takeInput )
            {
                // pass the input to the car!
                float h = CrossPlatformInputManager.GetAxis( "Horizontal" );
                float v = CrossPlatformInputManager.GetAxis( "Vertical" );
#if !MOBILE_INPUT
                float handbrake = CrossPlatformInputManager.GetAxis( "Jump" );
                m_Car.Move( h, v, v, handbrake );
#else
            m_Car.Move(h, v, v, 0f);
#endif
            }
        }

        private void OnTriggerEnter( Collider other )
        {
            
        }
        private void OnCollisionEnter( Collision collision )
        {
            if( collision.transform.gameObject.name == "ThirdPersonController")
            {
                collision.transform.gameObject.SetActive( false );
                _takeInput = true;

                Cameras.AutoCam.Instance.SetTarget( transform );

                //FindObjectOfType<UnityStandardAssets.Cameras.AutoCam>();
                //GameObject.Find("ThirdP")

            }
        }
    }
}
